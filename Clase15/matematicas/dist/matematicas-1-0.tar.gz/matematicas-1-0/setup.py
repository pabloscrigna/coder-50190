from setuptools import setup


setup(

    name="matematicas",
    version="1,0"
)